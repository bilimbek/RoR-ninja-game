module NinjaHelper
end
