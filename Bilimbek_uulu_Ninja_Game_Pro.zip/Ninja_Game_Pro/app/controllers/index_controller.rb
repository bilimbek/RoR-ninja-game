class IndexController < ApplicationController

end
